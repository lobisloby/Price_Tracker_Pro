console.log("✅ AliExpress Price Tracker: Content script loaded!");function h(){return window.location.hostname.includes("aliexpress")}function k(){return window.location.pathname.includes("/item/")}function u(){try{const e=['h1[data-pl="product-title"]',".product-title-text","h1.pdp-mod-product-badge-title",".pdp-info h1","h1"];let t="Unknown Product";for(const i of e){const a=document.querySelector(i);if(a?.textContent?.trim()){t=a.textContent.trim();break}}const r=[".product-price-value",".uniform-banner-box-price",'[class*="price--current"] span',".pdp-mod-product-badge-price",'[class*="Price"] span',".es--wrap--erdmtq8 span"];let n="0";for(const i of r){const a=document.querySelector(i);if(a?.textContent?.trim()){n=a.textContent.trim();break}}const s=n.match(/[\d.,]+/);let p=0;if(s){let i=s[0];i.includes(",")&&!i.includes(".")?i=i.replace(",","."):i=i.replace(",",""),p=parseFloat(i)||0}const d=n.match(/[$€£¥₽]/),b=d?d[0]:"$",y=[".magnifier-image",".pdp-mod-product-badge-img img",'[class*="slider"] img',".images-view-item img",".product-image img"];let m="";for(const i of y){const a=document.querySelector(i);if(a?.src){m=a.src;break}}const g=window.location.pathname.match(/\/item\/(\d+)/),x={id:g?g[1]:Date.now().toString(),title:t,price:p,currency:b,image:m,url:window.location.href,site:"aliexpress"};return console.log("📦 Extracted product data:",x),x}catch(e){return console.error("❌ Error extracting product data:",e),null}}const o={container:`
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 2147483647;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  `,button:`
    padding: 14px 24px;
    background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%);
    color: white;
    border: none;
    border-radius: 12px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 4px 20px rgba(255, 107, 53, 0.4);
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 8px;
  `,buttonHover:`
    transform: translateY(-3px);
    box-shadow: 0 8px 30px rgba(255, 107, 53, 0.5);
  `,buttonTracked:`
    background: linear-gradient(135deg, #10B981 0%, #059669 100%);
    box-shadow: 0 4px 20px rgba(16, 185, 129, 0.4);
  `,buttonError:`
    background: linear-gradient(135deg, #EF4444 0%, #DC2626 100%);
    box-shadow: 0 4px 20px rgba(239, 68, 68, 0.4);
  `,buttonWarning:`
    background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);
    box-shadow: 0 4px 20px rgba(245, 158, 11, 0.4);
  `,buttonChecking:`
    background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
    box-shadow: 0 4px 20px rgba(59, 130, 246, 0.4);
  `};function T(){const e=document.querySelector("#aliexpress-tracker-btn");e&&e.remove();const t=document.createElement("div");t.id="aliexpress-tracker-container",t.style.cssText=o.container;const r=document.createElement("button");return r.id="aliexpress-tracker-btn",r.innerHTML="🔍 Track Price",r.style.cssText=o.button,r.addEventListener("mouseenter",()=>{r.disabled||(r.style.cssText=o.button+o.buttonHover)}),r.addEventListener("mouseleave",()=>{r.disabled||(r.style.cssText=o.button)}),r.addEventListener("click",P),t.appendChild(r),document.body.appendChild(t),w(),r}async function w(){const e=document.querySelector("#aliexpress-tracker-btn");if(!e)return;const t=u();if(t)try{const n=(await chrome.runtime.sendMessage({type:"GET_PRODUCTS"}))?.products||[],s=t.url.split("?")[0];n.find(d=>d.url.split("?")[0]===s||d.id===t.id)&&(e.innerHTML="✅ Tracking",e.style.cssText=o.button+o.buttonTracked,e.disabled=!0,console.log("📊 Product is tracked, checking for price changes..."),setTimeout(()=>E(),1e3))}catch(r){console.error("Error checking if tracked:",r)}}function v(){const e=document.querySelector("#aliexpress-tracker-upgrade-modal");e&&e.remove();const t=document.createElement("div");t.id="aliexpress-tracker-upgrade-modal",t.innerHTML=`
    <div style="
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.6);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 2147483647;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      animation: fadeIn 0.2s ease;
    ">
      <div style="
        background: white;
        border-radius: 20px;
        padding: 32px;
        max-width: 400px;
        width: 90%;
        text-align: center;
        box-shadow: 0 25px 50px rgba(0,0,0,0.3);
        animation: slideUp 0.3s ease;
      ">
        <div style="font-size: 64px; margin-bottom: 16px;">🚀</div>
        <h2 style="font-size: 24px; font-weight: 700; color: #1f2937; margin-bottom: 8px;">
          Upgrade to Premium
        </h2>
        <p style="color: #6b7280; margin-bottom: 20px; font-size: 14px;">
          You've reached the free limit of <strong>5 products</strong>.<br>
          Upgrade to track <strong>unlimited products</strong>!
        </p>
        
        <div style="
          background: linear-gradient(135deg, #fff7ed 0%, #ffedd5 100%);
          border-radius: 12px;
          padding: 16px;
          margin-bottom: 20px;
        ">
          <div style="font-size: 32px; font-weight: 700; color: #ea580c;">
            $3 <span style="font-size: 14px; font-weight: 400; color: #9a3412;">one-time</span>
          </div>
          <div style="font-size: 12px; color: #9a3412;">Pay once, use forever!</div>
        </div>

        <div style="display: flex; flex-direction: column; gap: 12px;">
          <button id="upgrade-btn" style="
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #f97316 0%, #ea580c 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
          ">
            🛒 Get Premium
          </button>
          <button id="close-modal-btn" style="
            width: 100%;
            padding: 12px;
            background: #f3f4f6;
            color: #6b7280;
            border: none;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
          ">
            Maybe Later
          </button>
        </div>

        <p style="font-size: 11px; color: #9ca3af; margin-top: 16px;">
          Already have a key? Go to Dashboard → Premium to activate
        </p>
      </div>
    </div>
  `;const r=document.createElement("style");r.textContent=`
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    @keyframes slideUp {
      from { transform: translateY(20px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
  `,document.head.appendChild(r),document.body.appendChild(t),document.getElementById("upgrade-btn")?.addEventListener("click",()=>{window.open("https://pricetrackerr.lemonsqueezy.com/checkout/buy/4a86e7a2-ab7e-4e2e-b1be-b3c64c1ff4d1","_blank"),t.remove()}),document.getElementById("close-modal-btn")?.addEventListener("click",()=>{t.remove()}),t.addEventListener("click",n=>{n.target===t.firstElementChild&&t.remove()})}async function P(){const e=document.querySelector("#aliexpress-tracker-btn");if(!e)return;const t=u();if(!t||t.price===0){e.innerHTML="⚠️ Could not get price",e.style.cssText=o.button+o.buttonWarning,setTimeout(()=>{e.innerHTML="🔍 Track Price",e.style.cssText=o.button},2e3);return}e.innerHTML="⏳ Tracking...",e.disabled=!0;try{const r=await chrome.runtime.sendMessage({type:"TRACK_PRODUCT",data:t});if(console.log("Track response:",r),r?.success){e.innerHTML="✅ Tracking!",e.style.cssText=o.button+o.buttonTracked;const n=r.limit-r.currentCount;!r.isPro&&n<=2?c(`✅ Tracked! ${n} free slots left`,"warning"):c("✅ Product added to tracking!","success")}else r?.error==="limit_reached"?(e.innerHTML="🔒 Limit Reached",e.style.cssText=o.button+o.buttonWarning,e.disabled=!1,v(),setTimeout(()=>{e.innerHTML="🔍 Track Price",e.style.cssText=o.button},3e3)):(e.innerHTML="⚠️ "+(r?.error||"Already tracked"),e.style.cssText=o.button+o.buttonWarning,setTimeout(()=>{r?.error==="Already tracked"?(e.innerHTML="✅ Tracking",e.style.cssText=o.button+o.buttonTracked,e.disabled=!0):(e.innerHTML="🔍 Track Price",e.style.cssText=o.button,e.disabled=!1)},2e3))}catch(r){console.error("Error tracking product:",r),e.innerHTML="❌ Error",e.style.cssText=o.button+o.buttonError,e.disabled=!1,setTimeout(()=>{e.innerHTML="🔍 Track Price",e.style.cssText=o.button},2e3)}}async function E(){const e=u();if(!(!e||e.price===0))try{console.log("🔍 Checking price:",e.price),c("🔍 Checking price...","info");const t=await chrome.runtime.sendMessage({type:"CHECK_PRICE",data:e});console.log("📥 Price check response:",t),t?.priceDropped?(console.log(`🎉 Price dropped! ${t.oldPrice} → ${t.newPrice}`),C(t),c(`🎉 Price dropped ${t.savings}%! Check your alerts.`,"success")):t?.priceChanged?(console.log(`📈 Price changed: ${t.oldPrice} → ${t.newPrice}`),t.newPrice>t.oldPrice&&c(`📈 Price increased to ${e.currency}${t.newPrice}`,"warning")):t?.tracked===!1?console.log("ℹ️ Product not in tracking list"):(console.log("✅ Price unchanged"),c("✅ Price checked - no change","info"))}catch(t){console.error("Error checking price:",t)}}function c(e,t="info"){const r=document.querySelector("#aliexpress-tracker-toast");r&&r.remove();const n={success:"#10B981",error:"#EF4444",warning:"#F59E0B",info:"#3B82F6"},s=document.createElement("div");s.id="aliexpress-tracker-toast",s.textContent=e,s.style.cssText=`
    position: fixed;
    bottom: 80px;
    right: 20px;
    z-index: 2147483647;
    padding: 12px 20px;
    background: ${n[t]||n.info};
    color: white;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    animation: slideIn 0.3s ease;
    max-width: 300px;
  `,document.body.appendChild(s),setTimeout(()=>s.remove(),3e3)}function C(e){const t=document.querySelector("#aliexpress-tracker-banner");t&&t.remove();const r=document.createElement("div");r.id="aliexpress-tracker-banner",r.innerHTML=`
    <div style="display: flex; align-items: center; gap: 15px;">
      <span style="font-size: 32px;">🎉</span>
      <div>
        <div style="font-weight: 700; font-size: 16px; margin-bottom: 4px;">Price Dropped!</div>
        <div style="font-size: 14px;">
          <span style="text-decoration: line-through; opacity: 0.7;">${e.currency||"$"}${e.oldPrice}</span>
          <span style="margin: 0 8px;">→</span>
          <span style="font-weight: 700; font-size: 18px;">${e.currency||"$"}${e.newPrice}</span>
          <span style="background: white; color: #10B981; padding: 2px 8px; border-radius: 20px; margin-left: 10px; font-weight: 600;">
            -${e.savings}%
          </span>
        </div>
      </div>
      <button id="aliexpress-tracker-banner-close" style="
        margin-left: auto;
        background: rgba(255,255,255,0.2);
        border: none;
        color: white;
        width: 30px;
        height: 30px;
        border-radius: 50%;
        font-size: 18px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
      ">×</button>
    </div>
  `,r.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 2147483647;
    padding: 20px 24px;
    background: linear-gradient(135deg, #10B981 0%, #059669 100%);
    color: white;
    border-radius: 16px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    box-shadow: 0 10px 40px rgba(16, 185, 129, 0.4);
    animation: slideDown 0.4s ease;
    max-width: 400px;
  `;const n=document.createElement("style");n.textContent=`
    @keyframes slideDown {
      from { transform: translateY(-100%); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
  `,document.head.appendChild(n),document.body.appendChild(r),document.getElementById("aliexpress-tracker-banner-close")?.addEventListener("click",()=>{r.remove()}),setTimeout(()=>r.remove(),1e4)}function l(){if(!h()){console.log("Not on AliExpress, skipping...");return}if(!k()){console.log("Not a product page, skipping...");return}console.log("🛒 AliExpress product page detected"),T()}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",l):l();setTimeout(l,2e3);let f=location.href;new MutationObserver(()=>{location.href!==f&&(f=location.href,setTimeout(l,1e3))}).observe(document,{subtree:!0,childList:!0});
